# DE 2024 GROUP 14
The githup repository for data engineering
